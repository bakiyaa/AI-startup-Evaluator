const express = require('express');
const app = express();

app.post('/', (req, res) => {
    res.status(200).send('Hello World!');
});

const port = process.env.PORT || 8080;
app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
});