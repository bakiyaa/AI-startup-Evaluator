const { Storage } = require('@google-cloud/storage');
const { ImageAnnotatorClient } = require('@google-cloud/vision');
const { SpeechClient } = require('@google-cloud/speech');
const { VideoIntelligenceServiceClient } = require('@google-cloud/video-intelligence');
const mammoth = require('mammoth');

const storage = new Storage();
const visionClient = new ImageAnnotatorClient();
const speechClient = new SpeechClient();
const videoIntelligenceClient = new VideoIntelligenceServiceClient();

exports.processDocument = async (req, res) => {
    try {
        const { bucketName, fileName, contentType } = req.body;
        if (!bucketName || !fileName) {
            return res.status(400).send('Missing bucketName or fileName in request body.');
        }

        console.log(`Processing file: ${fileName} from bucket: ${bucketName} with content type: ${contentType}`);

        const fileBuffer = await storage.bucket(bucketName).file(fileName).download();
        const fileContent = fileBuffer[0];

        let extractedText = '';

        if (contentType === 'application/pdf') {
            console.log('Processing PDF with Vision API for OCR...');
            const gcsUri = `gs://${bucketName}/${fileName}`;
            const [result] = await visionClient.asyncBatchAnnotateFiles({
                requests: [{
                    inputConfig: {
                        gcsSource: { uri: gcsUri },
                        mimeType: 'application/pdf',
                    },
                    features: [{ type: 'DOCUMENT_TEXT_DETECTION' }],
                }],
            });
            if (result.responses && result.responses.length > 0 && result.responses[0].fullTextAnnotation) {
                extractedText = result.responses[0].fullTextAnnotation.text;
            }
            console.log('PDF OCR complete.');
        } else if (contentType.startsWith('image/')) {
            console.log('Processing image with Vision API for OCR...');
            const [result] = await visionClient.textDetection(fileContent);
            if (result.fullTextAnnotation) {
                extractedText = result.fullTextAnnotation.text;
            }
            console.log('Image OCR complete.');
        } else if (contentType.startsWith('audio/')) {
            console.log('Processing audio with Speech-to-Text API...');
            const gcsUri = `gs://${bucketName}/${fileName}`;
            const [operation] = await speechClient.longRunningRecognize({
                config: {
                    encoding: 'MP3',
                    languageCode: 'en-US',
                },
                audio: {
                    uri: gcsUri,
                },
            });
            const [response] = await operation.promise();
            extractedText = response.results.map(result => result.alternatives[0].transcript).join('\n');
            console.log('Audio transcription complete.');
        } else if (contentType.startsWith('video/')) {
            console.log('Processing video with Video Intelligence API for transcription...');
            const gcsUri = `gs://${bucketName}/${fileName}`;
            const [operation] = await videoIntelligenceClient.annotateVideo({
                inputUri: gcsUri,
                features: ['SPEECH_TRANSCRIPTION'],
                videoContext: {
                    speechTranscriptionConfig: {
                        languageCode: 'en-US',
                        enableAutomaticPunctuation: true,
                    },
                },
            });
            const [response] = await operation.promise();
            extractedText = response.annotationResults[0].speechTranscriptions.map(transcription =>
                transcription.alternatives[0].transcript
            ).join('\n');
            console.log('Video transcription complete.');
        } else if (contentType.startsWith('text/')) {
            console.log('Handling text file...');
            extractedText = fileContent.toString('utf8');
        } else if (contentType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
            console.log('Processing DOCX with Mammoth...');
            const result = await mammoth.extractRawText({ buffer: fileContent });
            extractedText = result.value;
            console.log('DOCX processing complete.');
        } else {
            console.log('Unsupported content type, skipping:', contentType);
        }

        res.status(200).send(extractedText);

    } catch (error) {
        console.error('Error in processDocument:', error);
        res.status(500).send('An error occurred while processing the document.');
    }
};